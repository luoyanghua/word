var vm = new Vue({
    el:'#app',
    data:{
        searchItemShow:0,//1-会诊医生 2-会诊状态
    },
    methods:{},
    mounted:function () { 
        this.$nextTick(function () {

        });
    }
});